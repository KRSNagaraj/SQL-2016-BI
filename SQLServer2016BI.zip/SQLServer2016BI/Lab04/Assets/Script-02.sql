USE [AdventureWorksDW2016];
GO

SELECT * FROM [etl].[CountrySales];
SELECT * FROM [etl].[CountrySales_LoadErrors];
SELECT * FROM [etl].[PackageExecutionLog];
GO
