USE [MDS];
GO

--Retrieve current City entity members for StateProvince AU-WA
SELECT * FROM [mdm].[tbl_1_1_EN] WHERE [uda_1_65] = 72;
GO

--Retrieve City entity row history members for StateProvince AU-WA
SELECT * FROM [mdm].[tbl_1_1_EN_HS] WHERE [uda_1_65] = 72;
GO
