USE [MDS];
GO

--Purpose: Tests where a text value is empty (NULL or empty string)
--Note: This is designed to be used as a Master Data Services business rule condition
--      The requirements are that the function must:
--      - Return a BIT value
--      - Only have a single parameter input, of type:
--        - NVARCHAR
--        - DATETIME2
--        - DECIMAL (precision 38, and a scale 0-7)
CREATE FUNCTION [usr].[IsTextValueEmpty]
(
	@Value NVARCHAR(250)
)
RETURNS BIT
AS
BEGIN
	RETURN
		CASE
			WHEN NULLIF(LTRIM(RTRIM(@Value)), N'') IS NULL THEN 1
			ELSE 0
		END;
END;
GO

--Purpose: Issues a sequence of IP addresses with a range from 220.100.0.1 to 220.100.255.255
CREATE SEQUENCE [usr].[IpAddress]
	START WITH 3697541121
	INCREMENT BY 1
	MAXVALUE 3697606655;
GO

--Purpose: Converts an IP address in decimal form to dot-decimal notation
CREATE FUNCTION [usr].[ConvertIntegerToIpAddress]
(
	@IPAddressDecimal BIGINT
)
RETURNS NVARCHAR(15)
AS
BEGIN
	DECLARE
		@Octet1 TINYINT
		,@Octet2 TINYINT
		,@Octet3 TINYINT
		,@Octet4 TINYINT
		,@Remainder BIGINT;

	SET @Octet1 = @IPAddressDecimal / 16777216;
	SET @Remainder = @IPAddressDecimal - (@Octet1 * CAST(16777216 AS BIGINT));

	SET @Octet2 = @Remainder / 65536;
	SET @Remainder = @Remainder - (@Octet2 * 65536);

	SET @Octet3 = @Remainder / 256;

	SET @Octet4 = @Remainder - (@Octet3 * 256);

	RETURN CONCAT(@Octet1, N'.', @Octet2, N'.', @Octet3, N'.', @Octet4);
END;
GO

--Purpose: Retrieves and assigns the next IP address where the IpAddressLocator value is empty
--Note: This is designed to be used as a Master Data Services business rule action
--      The requirements is that the stored procedure must include the following parameters
CREATE PROCEDURE [usr].[SetIpAddressLocator]
	@MemberIdList [mdm].[MemberId] READONLY
	,@ModelName NVARCHAR(MAX)
	,@VersionName NVARCHAR(MAX)
	,@EntityName NVARCHAR(MAX)
	,@BusinessRuleName NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO
		[stg].[City_Leaf]
		(
			[ImportType]
			,[BatchTag]
			,[Code]
			,[IpAddressLocator]
		)
	SELECT
		0
		,N'SetIpAddressLocator'
		,[Code]
		,[usr].[ConvertIntegerToIpAddress](NEXT VALUE FOR [usr].[IpAddress]) AS [IpAddressLocator]
	FROM
		@MemberIdList AS [mid];

	EXEC [stg].[udp_City_Leaf]
		@VersionName = @VersionName
		,@BatchTag = N'SetIpAddressLocator';
END;
GO
